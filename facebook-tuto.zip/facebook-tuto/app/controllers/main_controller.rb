class MainController < ApplicationController
  def home
  	
  end
  def unregistered
  	
  end
end
