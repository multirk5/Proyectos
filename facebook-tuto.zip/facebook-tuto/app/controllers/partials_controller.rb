class PartialsController < ApplicationController
  def nav
  end
end
