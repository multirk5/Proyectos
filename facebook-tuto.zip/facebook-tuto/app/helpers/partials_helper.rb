module PartialsHelper
end
